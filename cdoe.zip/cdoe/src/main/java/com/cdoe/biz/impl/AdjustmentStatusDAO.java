
package com.cdoe.biz.impl;

import org.apache.log4j.Logger;

import com.cdoe.biz.IAdjustmentStatusDAO;
import com.cdoe.db.hibernate.HibernateDAO;

public class AdjustmentStatusDAO extends HibernateDAO  implements IAdjustmentStatusDAO {

	private static final Logger logger = Logger.getLogger(AdjustmentStatusDAO.class);
	
}
