
package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.ElectionsDetail;

public interface IElectionsDAO {

}
