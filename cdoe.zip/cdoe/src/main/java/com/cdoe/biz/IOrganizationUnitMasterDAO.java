package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.OrganizationUnitMaster;

public interface IOrganizationUnitMasterDAO {

	public List<OrganizationUnitMaster> getAllOrganizations();
	
	public List<OrganizationUnitMaster> getOrganizationsByType(String organizationType);

	public OrganizationUnitMaster lookUpOrganization(String organizationCode);

}
