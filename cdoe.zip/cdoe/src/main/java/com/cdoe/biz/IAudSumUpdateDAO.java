
package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.AuditEqual;

public interface IAudSumUpdateDAO {

}
