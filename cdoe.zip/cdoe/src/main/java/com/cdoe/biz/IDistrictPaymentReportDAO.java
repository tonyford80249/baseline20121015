
package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.Prorate;
import com.cdoe.biz.model.Transportation;

public interface IDistrictPaymentReportDAO {

	List<Prorate> getDistrictPaymentReport(String fiscalYear);

	List<Transportation> getTransportationByFiscalYear(String fiscalYear);

}
