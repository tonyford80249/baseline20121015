/**
 * 
 */
package com.cdoe.services;

import com.cdoe.ui.form.AuditRepaymentAdjustmentForm;

/**
 * Interface for AuditRepaymentAdjustmentManager
 * 
 * @author dyn-8
 *
 */
public interface IAuditRepaymentAdjustmentManager extends IBaseManager {
	public void saveOrUpdate(AuditRepaymentAdjustmentForm form);
}
