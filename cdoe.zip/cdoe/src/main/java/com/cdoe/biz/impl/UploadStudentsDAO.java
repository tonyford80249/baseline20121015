
package com.cdoe.biz.impl;

import org.apache.log4j.Logger;

import com.cdoe.biz.IUploadStudentsDAO;
import com.cdoe.db.hibernate.HibernateDAO;

public class UploadStudentsDAO extends HibernateDAO  implements IUploadStudentsDAO {

	private static final Logger logger = Logger.getLogger(UploadStudentsDAO.class);
	
}
