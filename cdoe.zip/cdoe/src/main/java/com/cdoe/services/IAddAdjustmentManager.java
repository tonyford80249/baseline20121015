
package com.cdoe.services;

import com.cdoe.biz.model.Adjustment;
import com.cdoe.ui.form.AdjustmentForm;

public interface IAddAdjustmentManager extends IBaseManager {

	void saveOrUpdate(AdjustmentForm adjustmentForm);
	
	AdjustmentForm setupForm();
	
	AdjustmentForm setupForm(long id);

}
