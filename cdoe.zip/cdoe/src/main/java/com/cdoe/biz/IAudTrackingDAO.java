
package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.AuditFpc;

public interface IAudTrackingDAO {

}
