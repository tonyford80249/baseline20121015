
package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.AuditSasidException;

public interface IValidateSASIDsDAO {

}
