
package com.cdoe.biz.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.cdoe.biz.IMillLevyCertDAO;
import com.cdoe.db.hibernate.HibernateDAO;
import com.cdoe.biz.model.VData;

public class MillLevyCertDAO extends HibernateDAO  implements IMillLevyCertDAO {

	private static final Logger logger = Logger.getLogger(MillLevyCertDAO.class);
	
}
