package com.cdoe.biz.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.cdoe.biz.IOrganizationUnitMasterDAO;
import com.cdoe.biz.model.OrganizationUnitMaster;
import com.cdoe.db.hibernate.HibernateDAO;


@SuppressWarnings("unchecked")
public class OrganizationUnitMasterDAO extends HibernateDAO  implements  IOrganizationUnitMasterDAO {
	
	/**
	 * Returns a list of all organizations of type 'DISTRICT', 'BOCES', and 'FACILITY'
	 * 
	 * @return
	 */
	public List<OrganizationUnitMaster> getAllOrganizations() {
		Session session = getCurrentSession();
		Query query = session.createQuery("FROM OrganizationUnitMaster o where o.organizationUnitType in ('DISTRICT', 'BOCES', 'FACILITY')");
		return (List<OrganizationUnitMaster>)query.list();
	}
	
	/**
	 * Returns an OrganizationUnitMaster based on its code
	 * 
	 * @param organizationCode
	 * @return
	 */
	public OrganizationUnitMaster lookUpOrganization(String organizationCode) {
		Session session = getCurrentSession();
		Query query = session
				.createQuery("FROM OrganizationUnitMaster o where o.organizationCode = :organizationCode");
		query.setParameter("organizationCode", organizationCode);
		return (OrganizationUnitMaster)query.uniqueResult();
	}

	@Override
	public List<OrganizationUnitMaster> getOrganizationsByType(
			String organizationType) {
		Session session = getCurrentSession();
		Query query = session
				.createQuery("FROM OrganizationUnitMaster o where o.organizationUnitType = :organizationType");
		query.setParameter("organizationType", organizationType);
		return (List<OrganizationUnitMaster>) query.list();
	}

}
