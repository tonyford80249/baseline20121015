
package com.cdoe.biz;


public interface IAdjustmentStatusDAO {

}
