/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cdoe.biz.model;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRDataSourceProvider;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.JRPropertiesHolder;
import net.sf.jasperreports.engine.JRPropertiesMap;
import net.sf.jasperreports.engine.JasperReport;

/**
 *
 * @author dyn-9
 */
public class CustomJRDataSourceProvider implements  JRDataSourceProvider {
    
    public boolean supportsGetFieldsOperation() {
       return true;
    }

    public JRField[] getFields(JasperReport jr) throws JRException, UnsupportedOperationException {
        JRField[] returnValue = new JRField[10];
        
        
        
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public JRDataSource create(JasperReport jr) throws JRException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void dispose(JRDataSource jrds) throws JRException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
