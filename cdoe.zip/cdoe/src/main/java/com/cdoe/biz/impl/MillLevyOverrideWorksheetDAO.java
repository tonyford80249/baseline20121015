
package com.cdoe.biz.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.cdoe.biz.IMillLevyOverrideWorksheetDAO;
import com.cdoe.db.hibernate.HibernateDAO;
import com.cdoe.biz.model.VData;

public class MillLevyOverrideWorksheetDAO extends HibernateDAO  implements IMillLevyOverrideWorksheetDAO {

	private static final Logger logger = Logger.getLogger(MillLevyOverrideWorksheetDAO.class);
	
}
