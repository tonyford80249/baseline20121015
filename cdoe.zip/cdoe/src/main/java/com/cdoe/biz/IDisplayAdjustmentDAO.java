
package com.cdoe.biz;

import com.cdoe.biz.model.StateEqual;
import java.util.List;

import com.cdoe.biz.model.StateEqualbacked;

public interface IDisplayAdjustmentDAO {
 public abstract List<StateEqual> getStateEqualByDistrictAndYear(final String districtNos, final String fiscalYear); 
}
