package com.cdoe.services;

import java.util.List;
import java.util.Map;

public interface IReferenceDataManager {

	public String getOrganizationName(String orgCode);
	
	public Map<String, String> getAllOrganizationsMap();
	
	public Map<String, String> getOrganizationsMap(String orgType);
	
	public List<String> getMonthList();
	
	public List<String> getCrosswalkDataType();
	
	public List<String> getDistrictEntitlementPeriod();
	
	public List<String> getStateShareAdjustments();
	
	public String getLastPaymentDate();
	
	public List<String> getCrossWalkDataType();
	
	public List<String> getAuditRepaymentAdjustmentFrequencies();
}
