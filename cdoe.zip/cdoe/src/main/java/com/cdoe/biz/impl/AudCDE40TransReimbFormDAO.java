
package com.cdoe.biz.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.cdoe.biz.IAudCDE40TransReimbFormDAO;
import com.cdoe.db.hibernate.HibernateDAO;
import com.cdoe.biz.model.AuditTran;

public class AudCDE40TransReimbFormDAO extends HibernateDAO  implements IAudCDE40TransReimbFormDAO {

	private static final Logger logger = Logger.getLogger(AudCDE40TransReimbFormDAO.class);
	
}
