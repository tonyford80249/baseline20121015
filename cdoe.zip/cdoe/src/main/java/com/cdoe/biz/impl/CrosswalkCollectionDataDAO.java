
package com.cdoe.biz.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.cdoe.biz.ICrosswalkCollectionDataDAO;
import com.cdoe.db.hibernate.HibernateDAO;
import com.cdoe.biz.model.StateEqualbacked;

public class CrosswalkCollectionDataDAO extends HibernateDAO  implements ICrosswalkCollectionDataDAO {

	private static final Logger logger = Logger.getLogger(CrosswalkCollectionDataDAO.class);
	
}
