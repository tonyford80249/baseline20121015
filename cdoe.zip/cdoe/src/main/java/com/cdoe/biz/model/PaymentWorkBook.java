package com.cdoe.biz.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tony Ford
 */
public class PaymentWorkBook {
 List<PaymentWorkSheet> sheets = new ArrayList<PaymentWorkSheet>();   

    public PaymentWorkBook() {
    }

    public List<PaymentWorkSheet> getSheets() {
        return sheets;
    }

    public void setSheets(List<PaymentWorkSheet> sheets) {
        this.sheets = sheets;
    }
 
 
}
