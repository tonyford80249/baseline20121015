
package com.cdoe.biz.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.cdoe.biz.IMonthlyPaymentsDAO;
import com.cdoe.db.hibernate.HibernateDAO;
import com.cdoe.biz.model.District;

public class MonthlyPaymentsDAO extends HibernateDAO  implements IMonthlyPaymentsDAO {

	private static final Logger logger = Logger.getLogger(MonthlyPaymentsDAO.class);
	
}
