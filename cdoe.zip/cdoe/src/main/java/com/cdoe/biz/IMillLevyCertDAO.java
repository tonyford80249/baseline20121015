
package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.VData;

public interface IMillLevyCertDAO {

}
