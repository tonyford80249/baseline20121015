package com.canoe.voddai.demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;




/**
 *
 * @author romeo
 */
@Endpoint
public class UpdateNoticeEndPoint {
    //urn:cablelabs:safi:xsd:cip:3.0
  private static final String NAMESPACE_URI = "urn:cablelabs:safi:xsd:cip:3.0";

  private UpdateNotice updateNoticeService;

    @Autowired
    public UpdateNoticeEndPoint(UpdateNotice updateNoticeService) {
        this.updateNoticeService = updateNoticeService;
    }
  
    @PayloadRoot(namespace=NAMESPACE_URI, localPart="UpdateNotice")
    public String handleCipUpdateRequest(@RequestPayload String msg) {
      
     updateNoticeService.handleNotice(msg);
     
     return "<UpdateResponse msgResult=\"ok\"></UpdateResponse>";
    }
}
