/**
 * 
 */
package com.cdoe.biz.impl;

import com.cdoe.biz.IAuditRepaymentAdjustmentDAO;
import com.cdoe.db.hibernate.HibernateDAO;

/**
 * @author dyn-8
 *
 */
public class AuditRepaymentAdjustmentDAO extends HibernateDAO implements
		IAuditRepaymentAdjustmentDAO {

}
