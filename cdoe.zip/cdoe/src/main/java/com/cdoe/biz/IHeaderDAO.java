/*
 * Copyright ResQSoft, Inc. 2011
 */
package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.VHeader;

public interface IHeaderDAO {

}
