package com.canoe.voddai.demo1;

import org.springframework.stereotype.Component;

/**
 *
 * @author romeo
 */
@Component
public class UpdateNoticeImpl implements UpdateNotice{

    public String handleNotice(String msg) {
       System.out.println(msg); 
       
       return "";
    }
    
}
