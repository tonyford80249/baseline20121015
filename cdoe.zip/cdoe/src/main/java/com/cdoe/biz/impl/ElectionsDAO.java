
package com.cdoe.biz.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.cdoe.biz.IElectionsDAO;
import com.cdoe.db.hibernate.HibernateDAO;
import com.cdoe.biz.model.ElectionsDetail;

public class ElectionsDAO extends HibernateDAO  implements IElectionsDAO {

	private static final Logger logger = Logger.getLogger(ElectionsDAO.class);
	
}
