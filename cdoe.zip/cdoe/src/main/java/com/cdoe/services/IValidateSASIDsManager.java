
package com.cdoe.services;

import com.cdoe.biz.model.AuditSasidException;
import com.cdoe.ui.form.AuditSasidExceptionForm;

public interface IValidateSASIDsManager extends IBaseManager {

	void saveOrUpdate(AuditSasidExceptionForm auditSasidExceptionForm);
	
	AuditSasidExceptionForm setupForm();
	
	AuditSasidExceptionForm setupForm(long id);

}
