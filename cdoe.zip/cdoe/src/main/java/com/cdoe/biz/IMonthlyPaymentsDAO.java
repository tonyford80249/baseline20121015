
package com.cdoe.biz;

import java.util.List;

import com.cdoe.biz.model.District;

public interface IMonthlyPaymentsDAO {

}
