
package com.cdoe.biz.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.cdoe.biz.IAddAdjustmentDAO;
import com.cdoe.db.hibernate.HibernateDAO;
import com.cdoe.biz.model.Adjustment;

public class AddAdjustmentDAO extends HibernateDAO  implements IAddAdjustmentDAO {

	private static final Logger logger = Logger.getLogger(AddAdjustmentDAO.class);
	
}
